﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Tooter.Migrations
{
    public partial class SecondMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Toots_Users_CreatorUserId",
                table: "Toots");

            migrationBuilder.DropIndex(
                name: "IX_Toots_CreatorUserId",
                table: "Toots");

            migrationBuilder.DropColumn(
                name: "CreatorUserId",
                table: "Toots");

            migrationBuilder.AddColumn<int>(
                name: "UserId",
                table: "Toots",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Toots_UserId",
                table: "Toots",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Toots_Users_UserId",
                table: "Toots",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Toots_Users_UserId",
                table: "Toots");

            migrationBuilder.DropIndex(
                name: "IX_Toots_UserId",
                table: "Toots");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "Toots");

            migrationBuilder.AddColumn<int>(
                name: "CreatorUserId",
                table: "Toots",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Toots_CreatorUserId",
                table: "Toots",
                column: "CreatorUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Toots_Users_CreatorUserId",
                table: "Toots",
                column: "CreatorUserId",
                principalTable: "Users",
                principalColumn: "UserId");
        }
    }
}
