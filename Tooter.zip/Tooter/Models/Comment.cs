#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tooter.Models;

public class Comment{

    [Key]
    public int CommentId {get;set;}

    public string CommentText {get;set;}

    public int UserId {get;set;}

    public int TootId {get;set;}

    public DateTime CreatedAt {get;set;} = DateTime.Now;

    public DateTime UpdateAt {get;set;} = DateTime.Now;

    public User? Creator {get;set;}





}