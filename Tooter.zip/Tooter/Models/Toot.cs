#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tooter.Models;


public class Toot{

    [Key]
    public int TootId {get;set;}

    public string TootText {get;set;}

    public DateTime CreatedAt{get;set;} = DateTime.Now;

    public DateTime UpdatedAt {get;set;} = DateTime.Now;

    public User? Creator {get;set;}

    public int UserId {get;set;}

    public List<Like> Likes {get;set;} = new List<Like>();

    public List<Comment> Comments {get;set;} = new List<Comment>();


}