#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tooter.Models;



public class User{

    [Key]
    public int UserId {get;set;}

    public string FirstName {get;set;}

    public string LastName {get;set;}
    [Required]
    [EmailAddress]
    [UniqueEmail]
    public string Email {get;set;}
    [Required]
    public string Username {get;set;}
    [Required]
    public string Password {get;set;}

    [NotMapped]
    [Required]
    public string PasswordConfirm {get;set;}

    public DateTime CreatedAt {get;set;} = DateTime.Now;

    public DateTime UpdatedAt {get;set;} = DateTime.Now;


    public List<Follow>? Follows {get;set;} = new List<Follow>();

    public List<Toot>? CreatedToots {get;set;}

    public List<Like>? LikedToots {get;set;}

}