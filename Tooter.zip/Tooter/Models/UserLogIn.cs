#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tooter.Models;

public class UserLogIn{

    [Required]
    public string EmailLogIn {get;set;}


    [Required]
    public string PasswordLogIn {get;set;}




}