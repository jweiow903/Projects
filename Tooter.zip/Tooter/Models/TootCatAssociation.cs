#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tooter.Models;

public class TootCatAssociation{

    [Key]
    public int TootCatAssociationId {get;set;}

    public int TootId {get;set;}

    public int CategoryId {get;set;}

    public DateTime CreatedAt {get;set;} = DateTime.Now;

    public DateTime UpdatedAt {get;set;} = DateTime.Now;

    public List<Category>? Category {get;set;} = new List<Category>();

    public List<Toot>? Toot {get;set;} = new List<Toot>();




}