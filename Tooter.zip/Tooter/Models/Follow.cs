#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tooter.Models;


public class Follow{

    [Key]
    public int FollowId {get;set;}

    public int User1Id {get;set;}

    public int User2Id {get;set;}

    public DateTime CreatedAt {get;set;} = DateTime.Now;

    public DateTime UpdatedAt {get;set;} = DateTime.Now;  


    public List<User>? Follows {get;set;} = new List<User>();



}