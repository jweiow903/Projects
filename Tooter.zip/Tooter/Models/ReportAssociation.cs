#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tooter.Models;

public class ReportAssociation{


    [Key]
    public int ReportAssociationId {get;set;}

    public int UserId {get;set;}

    public int TootId {get;set;}



}