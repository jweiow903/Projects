using Microsoft.EntityFrameworkCore;
namespace Tooter.Models;

public class MyContext : DbContext {


    public MyContext(DbContextOptions options) : base(options) {}

    
    // public DbSet<Customer> Customers {get;set;}

    public DbSet<User> Users {get;set;}

    public DbSet<Toot> Toots {get;set;}

    public DbSet<Comment> Comments {get;set;}

    public DbSet<Like> Likes {get;set;}

    public DbSet<Follow> Follows {get;set;}

    public DbSet<Category> Categories {get;set;}

    public DbSet<TootCatAssociation> TootCatAssociations {get;set;}

    public DbSet<ReportAssociation> ReportAssociations {get;set;}

    // public DbSet<Product> Products {get;set;}

    // public DbSet<Order> Orders {get;set;}


}