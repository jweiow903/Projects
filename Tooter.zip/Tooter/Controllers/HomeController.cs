﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Tooter.Models;

namespace Tooter.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private MyContext _context;

    public HomeController(ILogger<HomeController> logger, MyContext context)
    {
        _logger = logger;
        _context = context;
    }

    [HttpPost("LogOut")]
    public IActionResult LogOut()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index");
    }


    [HttpGet("")]
    public IActionResult Index()
    {
        return View("Index");
    }

    [HttpGet("Feed")]
    public IActionResult Feed()
    {
        List<Toot>? AllToots = _context.Toots.Include(t => t.Creator).Include(t=>t.Likes).Include(t => t.Comments).ThenInclude(t=> t.Creator).ToList();
        List<Toot> PrepToots = new List<Toot>();
        for(int i = 0; i<3; i++){
            Random rand = new Random();
            PrepToots.Add(AllToots[rand.Next(AllToots.Count)]);
        }
        ViewBag.AllPosts = PrepToots;

        return View("Feed");
    }

    [HttpPost("Like")]
    public IActionResult Like(int newTootId, int newUserId)
    {
        Like newLike = new Like();
        newLike.UserId = newUserId;
        newLike.TootId = newTootId;

        Like? whatTheFuck = _context.Likes.Where(U => U.UserId == newUserId).Where(x => x.TootId == newTootId).FirstOrDefault();

        if(whatTheFuck == null){
        System.Console.WriteLine("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");




            _context.Add(newLike);
            _context.SaveChanges();
            return RedirectToAction("Feed");
        }
        else{

            _context.Remove(whatTheFuck);
            _context.SaveChanges();
            System.Console.WriteLine("+++++++++++++++++++ HERE");
            return RedirectToAction("Feed");

        }

    }

    [HttpPost("NewToot")]
    public IActionResult NewToot(Toot newToot){
        if(ModelState.IsValid){

            _context.Add(newToot);
            _context.SaveChanges();
            return RedirectToAction("Feed");
        }
        else return View("Feed");
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    [HttpPost("home/login")]
    public IActionResult LogIn(UserLogIn userSub){
        User? DBUser = _context.Users.FirstOrDefault(u => u.Email == userSub.EmailLogIn);
        if(DBUser == null){
            ModelState.AddModelError("Email", "Invalid Email/Password");
            return View("Index");
        }
        PasswordHasher<UserLogIn> hasher = new PasswordHasher<UserLogIn>();
        var result = hasher.VerifyHashedPassword(userSub, DBUser.Password, userSub.PasswordLogIn);
        if(result == 0){
            return View("Index");
        }
        else{
            HttpContext.Session.SetInt32("UserId", DBUser.UserId);
            HttpContext.Session.SetString("Username", DBUser.Username);
            return RedirectToAction("Feed");
        }

    }

    [HttpPost("home/register")]
    public IActionResult Register(User newUser)
    {
        System.Console.WriteLine(newUser);
        System.Console.WriteLine(newUser);
        if(ModelState.IsValid){
            PasswordHasher<User> Hasher = new PasswordHasher<User>();
            newUser.Password = Hasher.HashPassword(newUser, newUser.Password);
            _context.Add(newUser);
            _context.SaveChanges();
            HttpContext.Session.SetInt32("UserId", newUser.UserId);
            return RedirectToAction("Feed");
        }
        else{
            return View("Index");
        }
    }


}
