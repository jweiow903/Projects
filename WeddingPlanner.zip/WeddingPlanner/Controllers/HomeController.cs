﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using WeddingPlanner.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace WeddingPlanner.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private MyContext _context;

    public HomeController(ILogger<HomeController> logger,MyContext context)
    {
        _logger = logger;
        _context = context;
    }

    [HttpPost("home/login")]
    public IActionResult LogIn(UserLogin userSub){
    User? DBUser = _context.Users.FirstOrDefault(u => u.Email == userSub.Email);
    if(DBUser == null){
        ModelState.AddModelError("Email", "Invalid Email/Password");
        return View("Index");
    }
    PasswordHasher<UserLogin> hasher = new PasswordHasher<UserLogin>();
    var result = hasher.VerifyHashedPassword(userSub, DBUser.Password, userSub.Password);
    if(result == 0){
        return View("Index");
    }
    else{
        HttpContext.Session.SetInt32("UserId", DBUser.UserId);
        HttpContext.Session.SetString("UserName", DBUser.FirstName);
        return RedirectToAction("Weddings");
    }

    }
        [HttpPost("home/register")]
        public IActionResult Register(User newUser)
    {
        
        if(ModelState.IsValid){
            PasswordHasher<User> Hasher = new PasswordHasher<User>();
            newUser.Password = Hasher.HashPassword(newUser, newUser.Password);
            _context.Add(newUser);
            _context.SaveChanges();
            HttpContext.Session.SetInt32("UserId", newUser.UserId);
            HttpContext.Session.SetString("UserName", newUser.FirstName);
            return RedirectToAction("Weddings");
        }
        else{
            return View("Index");
        }
    }

    [HttpPost("home/NewWedding")]
    public IActionResult NewWedding(Wedding newWedding){

        if(ModelState.IsValid){
            _context.Add(newWedding);
            _context.SaveChanges();
            return RedirectToAction("Weddings");
        }
        else{
            return View("NewWedding");
        }
    }

    [HttpPost("home/destroy")]
    public IActionResult Destroy(int WeddingId){

        Wedding? WedToDel = _context.Weddings.SingleOrDefault(w=> w.WeddingId == WeddingId);
        
            
        
        
        _context.Weddings.Remove(WedToDel);
        _context.SaveChanges();
        return RedirectToAction("Weddings");
        
    }
    [SessionCheck]
    [HttpGet("weddings/{WeddingId}")]
    public IActionResult OneWedding(int WeddingId){

        // Wedding wed = _context.Weddings.FirstOrDefault(w => w.WeddingId == WeddingId);
        Wedding? wed = _context.Weddings.Include(w=> w.Guests).ThenInclude(g=> g.User).FirstOrDefault(w=> w.WeddingId == WeddingId);
        if(wed == null){
            return View("Weddings");
        }
        else{
        return View("OneWedding", wed);
        }

    }

    [HttpPost("home/unrsvp")]
    public IActionResult UnRSVP(int WeddingId, int UserId){

        RSVP? RSVPToDel = _context.RSVPs.SingleOrDefault(u => u.WeddingId == WeddingId && u.UserId == UserId);
            if(RSVPToDel == null || UserId != HttpContext.Session.GetInt32("UserId")){
                return View("Weddings");
            }
            else{
                _context.RSVPs.Remove(RSVPToDel);
                _context.SaveChanges();
                return RedirectToAction("Weddings");
            }
    }


    [SessionCheck]
    [HttpGet("home/AddWedding")]
    public IActionResult AddWedding(){

        return View("NewWedding");
    }



    [HttpGet("")]
    public IActionResult Index()
    {
        HttpContext.Session.Clear();
        return View();
    }

    [HttpPost("home/MakeRSVP")]
    public IActionResult MakeRSVP(RSVP newRSVP){

        if(ModelState.IsValid){
            _context.Add(newRSVP);
            _context.SaveChanges();
            return RedirectToAction("Weddings");
        }
        else{
            return View("Weddings");
        }
    }



    [SessionCheck]
    [HttpGet("Weddings")]
    public IActionResult Weddings()
    {
        ViewBag.LoggedUser = HttpContext.Session.GetInt32("UserId");

        ViewBag.Weddings = _context.Weddings.Include(w => w.Guests).ThenInclude(g => g.User).ToList();

        ViewBag.Test = _context.Users.FirstOrDefault(u => u.UserId == HttpContext.Session.GetInt32("UserId"));

        return View("Weddings");
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
