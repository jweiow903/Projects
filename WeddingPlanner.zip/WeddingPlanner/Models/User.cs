#pragma warning disable CS8618
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WeddingPlanner.Models;


public class User{

    [Key]
    public int UserId {get;set;}

    [Required]
    public string FirstName {get;set;}

    [Required]
    public string LastName {get;set;}

    [Required]
    [UniqueEmail]
    public string Email {get;set;}

    [Required]
    [DataType(DataType.Password)]
    [MinLength(8)]
    public string Password {get;set;}

    [Required]
    [NotMapped]
    [Compare("Password")]
    public string PasswordConfirm {get;set;}
    

    public DateTime CreatedAt {get;set;} = DateTime.Now;

    public DateTime UpdatedAt {get;set;} = DateTime.Now;

    
    public List<Wedding> CreatedWeddings {get;set;} = new List<Wedding>();

    public List<RSVP> AttendingWeddings {get;set;} = new List<RSVP>();

}